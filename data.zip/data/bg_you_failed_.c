#pragma bank 255

// Background: you failed 

#include "gbs_types.h"
#include "data/bg_you_failed__tileset.h"
#include "data/bg_you_failed__tilemap.h"
#include "data/bg_you_failed__tilemap_attr.h"

BANKREF(bg_you_failed_)

const struct background_t bg_you_failed_ = {
    .width = 20,
    .height = 18,
    .tileset = TO_FAR_PTR_T(bg_you_failed__tileset),
    .cgb_tileset = { NULL, NULL },
    .tilemap = TO_FAR_PTR_T(bg_you_failed__tilemap),
    .cgb_tilemap_attr = TO_FAR_PTR_T(bg_you_failed__tilemap_attr)
};
