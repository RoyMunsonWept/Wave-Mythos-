#pragma bank 255

// Scene: wave  1
// Triggers

#include "gbs_types.h"
#include "data/trigger_3_interact.h"
#include "data/trigger_4_interact.h"
#include "data/trigger_5_interact.h"
#include "data/trigger_6_interact.h"
#include "data/trigger_7_interact.h"
#include "data/trigger_8_interact.h"

BANKREF(scene_4_triggers)

const struct trigger_t scene_4_triggers[] = {
    {
        // bunker 2 trigger,
        .x = 2,
        .y = 32,
        .width = 2,
        .height = 2,
        .script = TO_FAR_PTR_T(trigger_3_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // bunker 0 trigger,
        .x = 10,
        .y = 45,
        .width = 2,
        .height = 2,
        .script = TO_FAR_PTR_T(trigger_4_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // bunker 1 trigger,
        .x = 8,
        .y = 36,
        .width = 2,
        .height = 2,
        .script = TO_FAR_PTR_T(trigger_5_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // bunker 3 trigger,
        .x = 15,
        .y = 26,
        .width = 2,
        .height = 2,
        .script = TO_FAR_PTR_T(trigger_6_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // bunker 4 trigger,
        .x = 12,
        .y = 17,
        .width = 2,
        .height = 2,
        .script = TO_FAR_PTR_T(trigger_7_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // bunker 5 trigger,
        .x = 6,
        .y = 18,
        .width = 2,
        .height = 2,
        .script = TO_FAR_PTR_T(trigger_8_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    }
};
