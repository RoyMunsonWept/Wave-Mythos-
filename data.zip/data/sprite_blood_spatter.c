#pragma bank 255
// SpriteSheet: blood spatter

#include "gbs_types.h"
#include "data/sprite_blood_spatter_tileset.h"
#include "data/sprite_blood_spatter_bank2_tileset.h"

BANKREF(sprite_blood_spatter)

#define SPRITE_1_STATE_DEFAULT 0
#define SPRITE_1_STATE_SELECT 0
#define SPRITE_1_STATE_LEFT_RUN_DOWN 0
#define SPRITE_1_STATE_RIGHT_RUN_UP 0
#define SPRITE_1_STATE_LEFT_RUN_UP 0
#define SPRITE_1_STATE_DEATH 0
#define SPRITE_1_STATE_RIGHT_RUN_DOWN 0
#define SPRITE_1_STATE_IDLE_LEFT 0
#define SPRITE_1_STATE_IDLE_RIGHT_UP 0
#define SPRITE_1_STATE_IDLE_LEFT_UP 0
#define SPRITE_1_STATE_HURT_DOWN_LEFT 0
#define SPRITE_1_STATE_HURT_UP_LEFT 0
#define SPRITE_1_STATE_HURT_RIGHT_DOWN 0
#define SPRITE_1_STATE_HURT_RIGHT_UP 0

const metasprite_t sprite_blood_spatter_metasprite_0[]  = {
    { 0, 8, 0, 7 }, { 0, -8, 2, 7 },
    {metasprite_end}
};

const metasprite_t sprite_blood_spatter_metasprite_1[]  = {
    { 0, 8, 0, 7 }, { 0, -8, 2, 7 }, { 0, 8, 4, 7 }, { 0, -8, 6, 7 },
    {metasprite_end}
};

const metasprite_t sprite_blood_spatter_metasprite_2[]  = {
    { 0, 8, 4, 7 }, { 0, -8, 6, 7 },
    {metasprite_end}
};

const metasprite_t sprite_blood_spatter_metasprite_3[]  = {
    { 1, 8, 0, 15 }, { 0, -8, 2, 15 },
    {metasprite_end}
};

const metasprite_t sprite_blood_spatter_metasprite_4[]  = {
    { 0, 9, 0, 15 }, { 0, -10, 2, 15 },
    {metasprite_end}
};

const metasprite_t sprite_blood_spatter_metasprite_5[]  = {
    { -1, 10, 0, 15 }, { 0, -12, 2, 15 },
    {metasprite_end}
};

const metasprite_t sprite_blood_spatter_metasprite_6[]  = {
    { 0, 11, 0, 15 }, { 0, -14, 2, 15 },
    {metasprite_end}
};

const metasprite_t sprite_blood_spatter_metasprite_7[]  = {
    { 0, 11, 4, 15 }, { 0, -14, 6, 15 },
    {metasprite_end}
};

const metasprite_t sprite_blood_spatter_metasprite_8[]  = {
    { 1, 12, 4, 15 }, { 0, -16, 6, 15 },
    {metasprite_end}
};

const metasprite_t sprite_blood_spatter_metasprite_9[]  = {
    { 2, 12, 4, 15 }, { 0, -16, 6, 15 },
    {metasprite_end}
};

const metasprite_t sprite_blood_spatter_metasprite_10[]  = {
    {metasprite_end}
};

const metasprite_t * const sprite_blood_spatter_metasprites[] = {
    sprite_blood_spatter_metasprite_0,
    sprite_blood_spatter_metasprite_0,
    sprite_blood_spatter_metasprite_1,
    sprite_blood_spatter_metasprite_2,
    sprite_blood_spatter_metasprite_2,
    sprite_blood_spatter_metasprite_3,
    sprite_blood_spatter_metasprite_4,
    sprite_blood_spatter_metasprite_5,
    sprite_blood_spatter_metasprite_6,
    sprite_blood_spatter_metasprite_7,
    sprite_blood_spatter_metasprite_8,
    sprite_blood_spatter_metasprite_9,
    sprite_blood_spatter_metasprite_10
};

const struct animation_t sprite_blood_spatter_animations[] = {
    {
        .start = 0,
        .end = 12
    },
    {
        .start = 0,
        .end = 12
    },
    {
        .start = 0,
        .end = 12
    },
    {
        .start = 0,
        .end = 12
    },
    {
        .start = 0,
        .end = 12
    },
    {
        .start = 0,
        .end = 12
    },
    {
        .start = 0,
        .end = 12
    },
    {
        .start = 0,
        .end = 12
    }
};

const UWORD sprite_blood_spatter_animations_lookup[] = {
    SPRITE_1_STATE_DEFAULT
};

const struct spritesheet_t sprite_blood_spatter = {
    .n_metasprites = 13,
    .emote_origin = {
        .x = 0,
        .y = -24
    },
    .metasprites = sprite_blood_spatter_metasprites,
    .animations = sprite_blood_spatter_animations,
    .animations_lookup = sprite_blood_spatter_animations_lookup,
    .bounds = {
        .left = 0,
        .bottom = 7,
        .right = 15,
        .top = -8
    },
    .tileset = TO_FAR_PTR_T(sprite_blood_spatter_tileset),
    .cgb_tileset = TO_FAR_PTR_T(sprite_blood_spatter_bank2_tileset)
};
