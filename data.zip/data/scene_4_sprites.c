#pragma bank 255

// Scene: wave  1
// Sprites

#include "gbs_types.h"
#include "data/sprite_roland_jr.h"
#include "data/sprite_bipedal_mutant.h"
#include "data/sprite_bunker.h"
#include "data/sprite_tablet_of_wave_mytho.h"
#include "data/sprite_monster_bullet.h"
#include "data/sprite_blood_spatter.h"

BANKREF(scene_4_sprites)

const far_ptr_t scene_4_sprites[] = {
    TO_FAR_PTR_T(sprite_roland_jr),
    TO_FAR_PTR_T(sprite_bipedal_mutant),
    TO_FAR_PTR_T(sprite_bunker),
    TO_FAR_PTR_T(sprite_tablet_of_wave_mytho),
    TO_FAR_PTR_T(sprite_monster_bullet),
    TO_FAR_PTR_T(sprite_blood_spatter)
};
