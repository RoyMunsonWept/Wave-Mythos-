#pragma bank 255

// Scene: wave  1
// Actors

#include "gbs_types.h"
#include "data/sprite_roland_jr.h"
#include "data/actor_2_update.h"
#include "data/sprite_bipedal_mutant.h"
#include "data/actor_4_update.h"
#include "data/actor_4_interact.h"
#include "data/sprite_bunker.h"
#include "data/actor_5_update.h"
#include "data/sprite_tablet_of_wave_mytho.h"
#include "data/actor_6_update.h"
#include "data/sprite_bunker.h"
#include "data/actor_7_update.h"
#include "data/sprite_bunker.h"
#include "data/actor_8_update.h"
#include "data/sprite_bunker.h"
#include "data/actor_15_update.h"
#include "data/sprite_bipedal_mutant.h"
#include "data/actor_0_update.h"
#include "data/actor_0_interact.h"

BANKREF(scene_4_actors)

const struct actor_t scene_4_actors[] = {
    {
        // player man,
        .pos = {
            .x = 80 * 16,
            .y = 368 * 16
        },
        .bounds = {
            .left = 3,
            .bottom = 7,
            .right = 12,
            .top = -6
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(sprite_roland_jr),
        .move_speed = 7,
        .anim_tick = 3,
        .pinned = FALSE,
        .persistent = TRUE,
        .collision_group = COLLISION_GROUP_NONE,
        .collision_enabled = TRUE,
        .script_update = TO_FAR_PTR_T(actor_2_update),
        .reserve_tiles = 0
    },
    {
        // monster 1,
        .pos = {
            .x = 56 * 16,
            .y = 424 * 16
        },
        .bounds = {
            .left = 4,
            .bottom = 7,
            .right = 9,
            .top = -7
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(sprite_bipedal_mutant),
        .move_speed = 2,
        .anim_tick = 3,
        .pinned = FALSE,
        .persistent = TRUE,
        .collision_group = COLLISION_GROUP_1,
        .collision_enabled = TRUE,
        .script_update = TO_FAR_PTR_T(actor_4_update),
        .script = TO_FAR_PTR_T(actor_4_interact),
        .reserve_tiles = 0
    },
    {
        // bunker tiles,
        .pos = {
            .x = 0 * 16,
            .y = 424 * 16
        },
        .bounds = {
            .left = 0,
            .bottom = 7,
            .right = 15,
            .top = -8
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(sprite_bunker),
        .move_speed = 16,
        .anim_tick = 15,
        .pinned = FALSE,
        .persistent = TRUE,
        .collision_group = COLLISION_GROUP_NONE,
        .collision_enabled = TRUE,
        .script_update = TO_FAR_PTR_T(actor_5_update),
        .reserve_tiles = 0
    },
    {
        // tablet of mythos,
        .pos = {
            .x = 40 * 16,
            .y = 80 * 16
        },
        .bounds = {
            .left = 0,
            .bottom = 7,
            .right = 15,
            .top = -8
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(sprite_tablet_of_wave_mytho),
        .move_speed = 3,
        .anim_tick = 7,
        .pinned = FALSE,
        .persistent = TRUE,
        .collision_group = COLLISION_GROUP_NONE,
        .collision_enabled = TRUE,
        .script_update = TO_FAR_PTR_T(actor_6_update),
        .reserve_tiles = 0
    },
    {
        // light house lamp,
        .pos = {
            .x = 40 * 16,
            .y = 48 * 16
        },
        .bounds = {
            .left = 0,
            .bottom = 7,
            .right = 15,
            .top = -8
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(sprite_bunker),
        .move_speed = 16,
        .anim_tick = 15,
        .pinned = FALSE,
        .persistent = FALSE,
        .collision_group = COLLISION_GROUP_NONE,
        .collision_enabled = TRUE,
        .script_update = TO_FAR_PTR_T(actor_7_update),
        .reserve_tiles = 0
    },
    {
        // wave tiles,
        .pos = {
            .x = 16 * 16,
            .y = 424 * 16
        },
        .bounds = {
            .left = 0,
            .bottom = 7,
            .right = 15,
            .top = -8
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(sprite_bunker),
        .move_speed = 16,
        .anim_tick = 15,
        .pinned = FALSE,
        .persistent = TRUE,
        .collision_group = COLLISION_GROUP_NONE,
        .collision_enabled = TRUE,
        .script_update = TO_FAR_PTR_T(actor_8_update),
        .reserve_tiles = 0
    },
    {
        // monster damage to player/ win state,
        .pos = {
            .x = 144 * 16,
            .y = 424 * 16
        },
        .bounds = {
            .left = 0,
            .bottom = 7,
            .right = 15,
            .top = -8
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(sprite_bunker),
        .move_speed = 16,
        .anim_tick = 15,
        .pinned = FALSE,
        .persistent = TRUE,
        .collision_group = COLLISION_GROUP_NONE,
        .collision_enabled = TRUE,
        .script_update = TO_FAR_PTR_T(actor_15_update),
        .reserve_tiles = 0
    },
    {
        // monster 2,
        .pos = {
            .x = 112 * 16,
            .y = 424 * 16
        },
        .bounds = {
            .left = 4,
            .bottom = 7,
            .right = 9,
            .top = -7
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(sprite_bipedal_mutant),
        .move_speed = 2,
        .anim_tick = 3,
        .pinned = FALSE,
        .persistent = TRUE,
        .collision_group = COLLISION_GROUP_1,
        .collision_enabled = TRUE,
        .script_update = TO_FAR_PTR_T(actor_0_update),
        .script = TO_FAR_PTR_T(actor_0_interact),
        .reserve_tiles = 0
    }
};
