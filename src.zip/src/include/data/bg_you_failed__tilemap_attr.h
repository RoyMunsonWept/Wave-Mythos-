#ifndef BG_YOU_FAILED__TILEMAP_ATTR_H
#define BG_YOU_FAILED__TILEMAP_ATTR_H

// Tilemap Attr bg_you_failed__tilemap_attr

#include "gbs_types.h"

BANKREF_EXTERN(bg_you_failed__tilemap_attr)
extern const unsigned char bg_you_failed__tilemap_attr[];

#endif
