#ifndef TRIGGER_4_INTERACT_H
#define TRIGGER_4_INTERACT_H

// Script trigger_4_interact

#include "gbs_types.h"

BANKREF_EXTERN(trigger_4_interact)
extern const unsigned char trigger_4_interact[];

#endif
