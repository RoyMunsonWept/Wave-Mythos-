#ifndef SPRITE_BIPEDAL_MUTANT_H
#define SPRITE_BIPEDAL_MUTANT_H

// SpriteSheet: bipedal_mutant

#include "gbs_types.h"

BANKREF_EXTERN(sprite_bipedal_mutant)
extern const struct spritesheet_t sprite_bipedal_mutant;

#endif
