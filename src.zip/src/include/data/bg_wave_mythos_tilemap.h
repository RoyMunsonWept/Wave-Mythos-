#ifndef BG_WAVE_MYTHOS_TILEMAP_H
#define BG_WAVE_MYTHOS_TILEMAP_H

// Tilemap bg_wave_mythos_tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_wave_mythos_tilemap)
extern const unsigned char bg_wave_mythos_tilemap[];

#endif
