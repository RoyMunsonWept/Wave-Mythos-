#ifndef TRIGGER_8_INTERACT_H
#define TRIGGER_8_INTERACT_H

// Script trigger_8_interact

#include "gbs_types.h"

BANKREF_EXTERN(trigger_8_interact)
extern const unsigned char trigger_8_interact[];

#endif
