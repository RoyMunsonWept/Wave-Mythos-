#ifndef SCENE_3_ACTORS_H
#define SCENE_3_ACTORS_H

// Scene: wave  1 back up
// Actors

#include "gbs_types.h"

BANKREF_EXTERN(scene_3_actors)
extern const struct actor_t scene_3_actors[];

#endif
