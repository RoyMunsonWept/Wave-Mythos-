#ifndef SCENE_3_COLLISIONS_H
#define SCENE_3_COLLISIONS_H

// Scene: wave  1 back up
// Collisions

#include "gbs_types.h"

BANKREF_EXTERN(scene_3_collisions)
extern const unsigned char scene_3_collisions[];

#endif
