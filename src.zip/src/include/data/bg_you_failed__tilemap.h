#ifndef BG_YOU_FAILED__TILEMAP_H
#define BG_YOU_FAILED__TILEMAP_H

// Tilemap bg_you_failed__tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_you_failed__tilemap)
extern const unsigned char bg_you_failed__tilemap[];

#endif
