#ifndef ACTOR_16_UPDATE_H
#define ACTOR_16_UPDATE_H

// Script actor_16_update

#include "gbs_types.h"

BANKREF_EXTERN(actor_16_update)
extern const unsigned char actor_16_update[];

#endif
