#ifndef TILESET_BUNKER_H
#define TILESET_BUNKER_H

// Tileset: tileset_bunker

#include "gbs_types.h"

BANKREF_EXTERN(tileset_bunker)
extern const struct tileset_t tileset_bunker;

#endif
