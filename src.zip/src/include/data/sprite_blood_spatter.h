#ifndef SPRITE_BLOOD_SPATTER_H
#define SPRITE_BLOOD_SPATTER_H

// SpriteSheet: blood spatter

#include "gbs_types.h"

BANKREF_EXTERN(sprite_blood_spatter)
extern const struct spritesheet_t sprite_blood_spatter;

#endif
