#ifndef TILESET_LIGHT_HOUSE_LAMP_H
#define TILESET_LIGHT_HOUSE_LAMP_H

// Tileset: tileset_light_house_lamp

#include "gbs_types.h"

BANKREF_EXTERN(tileset_light_house_lamp)
extern const struct tileset_t tileset_light_house_lamp;

#endif
