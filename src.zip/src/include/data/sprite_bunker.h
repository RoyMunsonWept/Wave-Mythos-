#ifndef SPRITE_BUNKER_H
#define SPRITE_BUNKER_H

// SpriteSheet: bunker

#include "gbs_types.h"

BANKREF_EXTERN(sprite_bunker)
extern const struct spritesheet_t sprite_bunker;

#endif
