#ifndef ACTOR_18_UPDATE_H
#define ACTOR_18_UPDATE_H

// Script actor_18_update

#include "gbs_types.h"

BANKREF_EXTERN(actor_18_update)
extern const unsigned char actor_18_update[];

#endif
