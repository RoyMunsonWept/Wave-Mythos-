#ifndef SCENE_0_INIT_H
#define SCENE_0_INIT_H

// Script scene_0_init

#include "gbs_types.h"

BANKREF_EXTERN(scene_0_init)
extern const unsigned char scene_0_init[];

#endif
