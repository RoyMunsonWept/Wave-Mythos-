#ifndef SPRITE_TABLET_OF_WAVE_MYTHO_TILESET_H
#define SPRITE_TABLET_OF_WAVE_MYTHO_TILESET_H

// Tileset: sprite_tablet_of_wave_mytho_tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_tablet_of_wave_mytho_tileset)
extern const struct tileset_t sprite_tablet_of_wave_mytho_tileset;

#endif
