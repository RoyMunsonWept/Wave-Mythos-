#ifndef ACTOR_0_UPDATE_H
#define ACTOR_0_UPDATE_H

// Script actor_0_update

#include "gbs_types.h"

BANKREF_EXTERN(actor_0_update)
extern const unsigned char actor_0_update[];

#endif
