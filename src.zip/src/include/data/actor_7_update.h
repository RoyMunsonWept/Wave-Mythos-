#ifndef ACTOR_7_UPDATE_H
#define ACTOR_7_UPDATE_H

// Script actor_7_update

#include "gbs_types.h"

BANKREF_EXTERN(actor_7_update)
extern const unsigned char actor_7_update[];

#endif
