#ifndef SCRIPT_INPUT_8_H
#define SCRIPT_INPUT_8_H

// Script script_input_8

#include "gbs_types.h"

BANKREF_EXTERN(script_input_8)
extern const unsigned char script_input_8[];

#endif
