#ifndef FRAME_IMAGE_H
#define FRAME_IMAGE_H

// Frame

#include "gbs_types.h"

BANKREF_EXTERN(frame_image)
extern const unsigned char frame_image[];

#endif
