#ifndef TRIGGER_16_INTERACT_H
#define TRIGGER_16_INTERACT_H

// Script trigger_16_interact

#include "gbs_types.h"

BANKREF_EXTERN(trigger_16_interact)
extern const unsigned char trigger_16_interact[];

#endif
