#ifndef SPRITE_ACTOR_ANIMATED_BANK2_TILESET_H
#define SPRITE_ACTOR_ANIMATED_BANK2_TILESET_H

// Tileset: sprite_actor_animated_bank2_tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_actor_animated_bank2_tileset)
extern const struct tileset_t sprite_actor_animated_bank2_tileset;

#endif
