#ifndef BG_WAVE_1_H
#define BG_WAVE_1_H

// Background: wave-1

#include "gbs_types.h"

BANKREF_EXTERN(bg_wave_1)
extern const struct background_t bg_wave_1;

#endif
