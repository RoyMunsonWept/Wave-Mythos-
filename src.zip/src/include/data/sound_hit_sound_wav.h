#ifndef __sound_hit_sound_wav_INCLUDE__
  #define __sound_hit_sound_wav_INCLUDE__
  
  #include <gbdk/platform.h>
  #include <stdint.h>
  
  #define MUTE_MASK_sound_hit_sound_wav 0b00000100
  
  BANKREF_EXTERN(sound_hit_sound_wav)
  extern const uint8_t sound_hit_sound_wav[];
  extern void __mute_mask_sound_hit_sound_wav;
  
  #endif
      