#ifndef TRIGGER_6_INTERACT_H
#define TRIGGER_6_INTERACT_H

// Script trigger_6_interact

#include "gbs_types.h"

BANKREF_EXTERN(trigger_6_interact)
extern const unsigned char trigger_6_interact[];

#endif
