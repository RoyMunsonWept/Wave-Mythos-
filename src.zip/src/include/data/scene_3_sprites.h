#ifndef SCENE_3_SPRITES_H
#define SCENE_3_SPRITES_H

// Scene: wave  1 back up
// Sprites

#include "gbs_types.h"

BANKREF_EXTERN(scene_3_sprites)
extern const far_ptr_t scene_3_sprites[];

#endif
