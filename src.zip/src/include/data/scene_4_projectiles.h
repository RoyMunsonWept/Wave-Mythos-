#ifndef SCENE_4_PROJECTILES_H
#define SCENE_4_PROJECTILES_H

// Scene: wave  1
// Projectiles

#include "gbs_types.h"

BANKREF_EXTERN(scene_4_projectiles)
extern const far_ptr_t scene_4_projectiles[];

#endif
