#ifndef SCENE_4_COLLISIONS_H
#define SCENE_4_COLLISIONS_H

// Scene: wave  1
// Collisions

#include "gbs_types.h"

BANKREF_EXTERN(scene_4_collisions)
extern const unsigned char scene_4_collisions[];

#endif
