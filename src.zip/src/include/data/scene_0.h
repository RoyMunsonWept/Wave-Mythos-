#ifndef SCENE_0_H
#define SCENE_0_H

// Scene: wave 1 screen

#include "gbs_types.h"

BANKREF_EXTERN(scene_0)
extern const struct scene_t scene_0;

#endif
