#ifndef SCENE_4_SPRITES_H
#define SCENE_4_SPRITES_H

// Scene: wave  1
// Sprites

#include "gbs_types.h"

BANKREF_EXTERN(scene_4_sprites)
extern const far_ptr_t scene_4_sprites[];

#endif
