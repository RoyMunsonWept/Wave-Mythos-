#ifndef BG_WAVE_1_COMPLETED_H
#define BG_WAVE_1_COMPLETED_H

// Background: wave-1_completed

#include "gbs_types.h"

BANKREF_EXTERN(bg_wave_1_completed)
extern const struct background_t bg_wave_1_completed;

#endif
