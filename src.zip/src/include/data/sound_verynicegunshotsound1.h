#ifndef __sound_verynicegunshotsound1_INCLUDE__
  #define __sound_verynicegunshotsound1_INCLUDE__
  
  #include <gbdk/platform.h>
  #include <stdint.h>
  
  #define MUTE_MASK_sound_verynicegunshotsound1 0b00000100
  
  BANKREF_EXTERN(sound_verynicegunshotsound1)
  extern const uint8_t sound_verynicegunshotsound1[];
  extern void __mute_mask_sound_verynicegunshotsound1;
  
  #endif
      