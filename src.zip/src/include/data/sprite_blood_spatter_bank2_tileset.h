#ifndef SPRITE_BLOOD_SPATTER_BANK2_TILESET_H
#define SPRITE_BLOOD_SPATTER_BANK2_TILESET_H

// Tileset: sprite_blood_spatter_bank2_tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_blood_spatter_bank2_tileset)
extern const struct tileset_t sprite_blood_spatter_bank2_tileset;

#endif
