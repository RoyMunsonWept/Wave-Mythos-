#ifndef TILESET_WAVES_H
#define TILESET_WAVES_H

// Tileset: tileset_waves

#include "gbs_types.h"

BANKREF_EXTERN(tileset_waves)
extern const struct tileset_t tileset_waves;

#endif
