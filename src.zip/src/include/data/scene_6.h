#ifndef SCENE_6_H
#define SCENE_6_H

// Scene: game over 

#include "gbs_types.h"

BANKREF_EXTERN(scene_6)
extern const struct scene_t scene_6;

#endif
