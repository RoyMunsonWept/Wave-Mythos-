#ifndef BG_WAVE_MYTHOS_CGB_TILESET_H
#define BG_WAVE_MYTHOS_CGB_TILESET_H

// Tileset: bg_wave_mythos_cgb_tileset

#include "gbs_types.h"

BANKREF_EXTERN(bg_wave_mythos_cgb_tileset)
extern const struct tileset_t bg_wave_mythos_cgb_tileset;

#endif
