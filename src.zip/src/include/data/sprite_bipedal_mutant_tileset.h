#ifndef SPRITE_BIPEDAL_MUTANT_TILESET_H
#define SPRITE_BIPEDAL_MUTANT_TILESET_H

// Tileset: sprite_bipedal_mutant_tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_bipedal_mutant_tileset)
extern const struct tileset_t sprite_bipedal_mutant_tileset;

#endif
