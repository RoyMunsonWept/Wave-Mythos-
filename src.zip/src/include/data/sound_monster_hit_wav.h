#ifndef __sound_monster_hit_wav_INCLUDE__
  #define __sound_monster_hit_wav_INCLUDE__
  
  #include <gbdk/platform.h>
  #include <stdint.h>
  
  #define MUTE_MASK_sound_monster_hit_wav 0b00000100
  
  BANKREF_EXTERN(sound_monster_hit_wav)
  extern const uint8_t sound_monster_hit_wav[];
  extern void __mute_mask_sound_monster_hit_wav;
  
  #endif
      