#ifndef BG_WAVE_1_COMPLETED_TILESET_H
#define BG_WAVE_1_COMPLETED_TILESET_H

// Tileset: bg_wave_1_completed_tileset

#include "gbs_types.h"

BANKREF_EXTERN(bg_wave_1_completed_tileset)
extern const struct tileset_t bg_wave_1_completed_tileset;

#endif
