#ifndef ACTOR_20_UPDATE_H
#define ACTOR_20_UPDATE_H

// Script actor_20_update

#include "gbs_types.h"

BANKREF_EXTERN(actor_20_update)
extern const unsigned char actor_20_update[];

#endif
