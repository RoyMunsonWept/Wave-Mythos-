#ifndef SPRITE_MONSTER_BULLET_H
#define SPRITE_MONSTER_BULLET_H

// SpriteSheet: bullet

#include "gbs_types.h"

BANKREF_EXTERN(sprite_monster_bullet)
extern const struct spritesheet_t sprite_monster_bullet;

#endif
