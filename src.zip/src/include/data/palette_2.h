#ifndef PALETTE_2_H
#define PALETTE_2_H

// Palette: 2

#include "gbs_types.h"

BANKREF_EXTERN(palette_2)
extern const struct palette_t palette_2;

#endif
