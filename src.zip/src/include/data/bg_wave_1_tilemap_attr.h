#ifndef BG_WAVE_1_TILEMAP_ATTR_H
#define BG_WAVE_1_TILEMAP_ATTR_H

// Tilemap Attr bg_wave_1_tilemap_attr

#include "gbs_types.h"

BANKREF_EXTERN(bg_wave_1_tilemap_attr)
extern const unsigned char bg_wave_1_tilemap_attr[];

#endif
