#ifndef BG_WAVE_1_COMPLETED_TILEMAP_H
#define BG_WAVE_1_COMPLETED_TILEMAP_H

// Tilemap bg_wave_1_completed_tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_wave_1_completed_tilemap)
extern const unsigned char bg_wave_1_completed_tilemap[];

#endif
