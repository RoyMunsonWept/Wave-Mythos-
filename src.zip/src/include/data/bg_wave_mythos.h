#ifndef BG_WAVE_MYTHOS_H
#define BG_WAVE_MYTHOS_H

// Background: wave mythos

#include "gbs_types.h"

BANKREF_EXTERN(bg_wave_mythos)
extern const struct background_t bg_wave_mythos;

#endif
