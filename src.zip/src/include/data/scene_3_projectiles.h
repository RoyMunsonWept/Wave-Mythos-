#ifndef SCENE_3_PROJECTILES_H
#define SCENE_3_PROJECTILES_H

// Scene: wave  1 back up
// Projectiles

#include "gbs_types.h"

BANKREF_EXTERN(scene_3_projectiles)
extern const far_ptr_t scene_3_projectiles[];

#endif
