#ifndef ACTOR_5_UPDATE_H
#define ACTOR_5_UPDATE_H

// Script actor_5_update

#include "gbs_types.h"

BANKREF_EXTERN(actor_5_update)
extern const unsigned char actor_5_update[];

#endif
