#ifndef SPRITE_MONSTER_BULLET_TILESET_H
#define SPRITE_MONSTER_BULLET_TILESET_H

// Tileset: sprite_monster_bullet_tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_monster_bullet_tileset)
extern const struct tileset_t sprite_monster_bullet_tileset;

#endif
