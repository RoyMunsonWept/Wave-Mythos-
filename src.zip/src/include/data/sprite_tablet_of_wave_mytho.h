#ifndef SPRITE_TABLET_OF_WAVE_MYTHO_H
#define SPRITE_TABLET_OF_WAVE_MYTHO_H

// SpriteSheet: tablet of wave mythos

#include "gbs_types.h"

BANKREF_EXTERN(sprite_tablet_of_wave_mytho)
extern const struct spritesheet_t sprite_tablet_of_wave_mytho;

#endif
