#ifndef ACTOR_0_INTERACT_H
#define ACTOR_0_INTERACT_H

// Script actor_0_interact

#include "gbs_types.h"

BANKREF_EXTERN(actor_0_interact)
extern const unsigned char actor_0_interact[];

#endif
