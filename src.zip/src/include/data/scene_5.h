#ifndef SCENE_5_H
#define SCENE_5_H

// Scene: wave 1 completed

#include "gbs_types.h"

BANKREF_EXTERN(scene_5)
extern const struct scene_t scene_5;

#endif
