#ifndef ACTOR_4_UPDATE_H
#define ACTOR_4_UPDATE_H

// Script actor_4_update

#include "gbs_types.h"

BANKREF_EXTERN(actor_4_update)
extern const unsigned char actor_4_update[];

#endif
