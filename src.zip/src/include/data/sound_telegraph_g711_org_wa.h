#ifndef __sound_telegraph_g711_org_wa_INCLUDE__
  #define __sound_telegraph_g711_org_wa_INCLUDE__
  
  #include <gbdk/platform.h>
  #include <stdint.h>
  
  #define MUTE_MASK_sound_telegraph_g711_org_wa 0b00000100
  
  BANKREF_EXTERN(sound_telegraph_g711_org_wa)
  extern const uint8_t sound_telegraph_g711_org_wa[];
  extern void __mute_mask_sound_telegraph_g711_org_wa;
  
  #endif
      