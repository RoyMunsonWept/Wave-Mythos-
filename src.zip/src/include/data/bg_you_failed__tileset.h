#ifndef BG_YOU_FAILED__TILESET_H
#define BG_YOU_FAILED__TILESET_H

// Tileset: bg_you_failed__tileset

#include "gbs_types.h"

BANKREF_EXTERN(bg_you_failed__tileset)
extern const struct tileset_t bg_you_failed__tileset;

#endif
