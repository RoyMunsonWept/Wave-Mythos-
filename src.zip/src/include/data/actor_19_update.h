#ifndef ACTOR_19_UPDATE_H
#define ACTOR_19_UPDATE_H

// Script actor_19_update

#include "gbs_types.h"

BANKREF_EXTERN(actor_19_update)
extern const unsigned char actor_19_update[];

#endif
