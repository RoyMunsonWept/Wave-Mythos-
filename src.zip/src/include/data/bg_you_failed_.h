#ifndef BG_YOU_FAILED__H
#define BG_YOU_FAILED__H

// Background: you failed 

#include "gbs_types.h"

BANKREF_EXTERN(bg_you_failed_)
extern const struct background_t bg_you_failed_;

#endif
