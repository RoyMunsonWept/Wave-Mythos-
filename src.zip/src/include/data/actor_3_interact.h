#ifndef ACTOR_3_INTERACT_H
#define ACTOR_3_INTERACT_H

// Script actor_3_interact

#include "gbs_types.h"

BANKREF_EXTERN(actor_3_interact)
extern const unsigned char actor_3_interact[];

#endif
