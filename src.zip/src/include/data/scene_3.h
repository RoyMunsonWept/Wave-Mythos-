#ifndef SCENE_3_H
#define SCENE_3_H

// Scene: wave  1 back up

#include "gbs_types.h"

BANKREF_EXTERN(scene_3)
extern const struct scene_t scene_3;

#endif
