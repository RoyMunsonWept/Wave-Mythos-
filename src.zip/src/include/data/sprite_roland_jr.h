#ifndef SPRITE_ROLAND_JR_H
#define SPRITE_ROLAND_JR_H

// SpriteSheet: roland_jr

#include "gbs_types.h"

BANKREF_EXTERN(sprite_roland_jr)
extern const struct spritesheet_t sprite_roland_jr;

#endif
