#ifndef STATE_ADVENTURE_H
#define STATE_ADVENTURE_H

#include <gbdk/platform.h>

void adventure_init(void) BANKED;
void adventure_update(void) BANKED;

#endif
