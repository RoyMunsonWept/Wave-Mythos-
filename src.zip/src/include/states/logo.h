#ifndef STATE_LOGO_H
#define STATE_LOGO_H

#include <gbdk/platform.h>

void logo_init(void) BANKED;
void logo_update(void) BANKED;

#endif
