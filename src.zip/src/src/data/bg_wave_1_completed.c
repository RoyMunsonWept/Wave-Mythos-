#pragma bank 255

// Background: wave-1_completed

#include "gbs_types.h"
#include "data/bg_wave_1_completed_tileset.h"
#include "data/bg_wave_1_completed_tilemap.h"
#include "data/bg_wave_1_completed_tilemap_attr.h"

BANKREF(bg_wave_1_completed)

const struct background_t bg_wave_1_completed = {
    .width = 20,
    .height = 18,
    .tileset = TO_FAR_PTR_T(bg_wave_1_completed_tileset),
    .cgb_tileset = { NULL, NULL },
    .tilemap = TO_FAR_PTR_T(bg_wave_1_completed_tilemap),
    .cgb_tilemap_attr = TO_FAR_PTR_T(bg_wave_1_completed_tilemap_attr)
};
