#pragma bank 255
// SpriteSheet: bipedal_mutant

#include "gbs_types.h"
#include "data/sprite_bipedal_mutant_tileset.h"
#include "data/sprite_bipedal_mutant_bank2_tileset.h"

BANKREF(sprite_bipedal_mutant)

#define SPRITE_4_STATE_DEFAULT 0
#define SPRITE_4_STATE_SELECT 0
#define SPRITE_4_STATE_LEFT_RUN_DOWN 16
#define SPRITE_4_STATE_RIGHT_RUN_UP 8
#define SPRITE_4_STATE_LEFT_RUN_UP 24
#define SPRITE_4_STATE_DEATH 32
#define SPRITE_4_STATE_RIGHT_RUN_DOWN 0
#define SPRITE_4_STATE_IDLE_LEFT 0
#define SPRITE_4_STATE_IDLE_RIGHT_UP 0
#define SPRITE_4_STATE_IDLE_LEFT_UP 0
#define SPRITE_4_STATE_HURT_DOWN_LEFT 40
#define SPRITE_4_STATE_HURT_UP_LEFT 48
#define SPRITE_4_STATE_HURT_RIGHT_DOWN 56
#define SPRITE_4_STATE_HURT_RIGHT_UP 64

const metasprite_t sprite_bipedal_mutant_metasprite_0[]  = {
    { 0, 8, 0, 0 }, { 0, -8, 2, 0 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_1[]  = {
    { 0, 8, 4, 0 }, { 0, -8, 6, 0 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_2[]  = {
    { 0, 8, 8, 0 }, { 0, -8, 10, 0 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_3[]  = {
    { 0, 8, 12, 0 }, { 0, -8, 14, 0 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_4[]  = {
    { 0, 8, 16, 0 }, { 0, -8, 18, 0 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_5[]  = {
    { 0, 8, 20, 0 }, { 0, -8, 22, 0 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_6[]  = {
    { 0, 8, 24, 0 }, { 0, -8, 26, 0 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_7[]  = {
    { 0, 8, 28, 0 }, { 0, -8, 30, 0 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_8[]  = {
    { 0, 8, 32, 0 }, { 0, -8, 0, 8 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_9[]  = {
    { 0, 8, 2, 8 }, { 0, -8, 4, 8 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_10[]  = {
    { 0, 8, 6, 8 }, { 0, -8, 8, 8 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_11[]  = {
    { 0, 8, 10, 8 }, { 0, -8, 12, 8 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_12[]  = {
    { 0, 0, 0, 32 }, { 0, 8, 2, 32 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_13[]  = {
    { 0, 0, 4, 32 }, { 0, 8, 6, 32 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_14[]  = {
    { 0, 0, 8, 32 }, { 0, 8, 10, 32 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_15[]  = {
    { 0, 0, 12, 32 }, { 0, 8, 14, 32 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_16[]  = {
    { 0, 0, 16, 32 }, { 0, 8, 18, 32 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_17[]  = {
    { 0, 0, 20, 32 }, { 0, 8, 22, 32 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_18[]  = {
    { 0, 0, 24, 32 }, { 0, 8, 26, 32 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_19[]  = {
    { 0, 0, 28, 32 }, { 0, 8, 30, 32 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_20[]  = {
    { 0, 0, 32, 32 }, { 0, 8, 0, 40 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_21[]  = {
    { 0, 0, 2, 40 }, { 0, 8, 4, 40 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_22[]  = {
    { 0, 0, 6, 40 }, { 0, 8, 8, 40 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_23[]  = {
    { 0, 0, 10, 40 }, { 0, 8, 12, 40 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_24[]  = {
    { 0, 8, 16, 7 }, { 0, -8, 18, 7 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_25[]  = {
    { 0, 8, 14, 15 }, { 0, -8, 16, 15 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_26[]  = {
    { 0, 8, 18, 15 }, { 0, -8, 20, 15 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_27[]  = {
    { 0, 8, 22, 15 }, { 0, -8, 24, 15 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_28[]  = {
    { 0, 8, 26, 15 }, { 0, -8, 28, 15 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_29[]  = {
    { 0, 8, 30, 15 }, { 0, -8, 32, 15 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_30[]  = {
    { 0, 0, 0, 39 }, { 0, 8, 2, 39 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_31[]  = {
    { 0, 0, 4, 39 }, { 0, 8, 6, 39 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_32[]  = {
    { 0, 0, 8, 39 }, { 0, 8, 10, 39 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_33[]  = {
    { 0, 0, 12, 39 }, { 0, 8, 14, 39 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_34[]  = {
    { 0, 0, 16, 39 }, { 0, 8, 18, 39 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_35[]  = {
    { 0, 0, 20, 39 }, { 0, 8, 22, 39 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_36[]  = {
    { 0, 0, 24, 39 }, { 0, 8, 26, 39 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_37[]  = {
    { 0, 0, 28, 39 }, { 0, 8, 30, 39 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_38[]  = {
    { 0, 0, 32, 39 }, { 0, 8, 0, 47 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_39[]  = {
    { 0, 0, 2, 47 }, { 0, 8, 4, 47 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_40[]  = {
    { 0, 0, 6, 47 }, { 0, 8, 8, 47 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_41[]  = {
    { 0, 0, 10, 47 }, { 0, 8, 12, 47 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_42[]  = {
    { 0, 8, 0, 7 }, { 0, -8, 2, 7 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_43[]  = {
    { 0, 8, 4, 7 }, { 0, -8, 6, 7 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_44[]  = {
    { 0, 8, 8, 7 }, { 0, -8, 10, 7 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_45[]  = {
    { 0, 8, 12, 7 }, { 0, -8, 14, 7 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_46[]  = {
    { 0, 8, 20, 7 }, { 0, -8, 22, 7 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_47[]  = {
    { 0, 8, 24, 7 }, { 0, -8, 26, 7 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_48[]  = {
    { 0, 8, 28, 7 }, { 0, -8, 30, 7 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_49[]  = {
    { 0, 8, 32, 7 }, { 0, -8, 0, 15 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_50[]  = {
    { 0, 8, 2, 15 }, { 0, -8, 4, 15 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_51[]  = {
    { 0, 8, 6, 15 }, { 0, -8, 8, 15 },
    {metasprite_end}
};

const metasprite_t sprite_bipedal_mutant_metasprite_52[]  = {
    { 0, 8, 10, 15 }, { 0, -8, 12, 15 },
    {metasprite_end}
};

const metasprite_t * const sprite_bipedal_mutant_metasprites[] = {
    sprite_bipedal_mutant_metasprite_0,
    sprite_bipedal_mutant_metasprite_0,
    sprite_bipedal_mutant_metasprite_0,
    sprite_bipedal_mutant_metasprite_1,
    sprite_bipedal_mutant_metasprite_1,
    sprite_bipedal_mutant_metasprite_2,
    sprite_bipedal_mutant_metasprite_3,
    sprite_bipedal_mutant_metasprite_3,
    sprite_bipedal_mutant_metasprite_3,
    sprite_bipedal_mutant_metasprite_4,
    sprite_bipedal_mutant_metasprite_4,
    sprite_bipedal_mutant_metasprite_5,
    sprite_bipedal_mutant_metasprite_6,
    sprite_bipedal_mutant_metasprite_6,
    sprite_bipedal_mutant_metasprite_6,
    sprite_bipedal_mutant_metasprite_7,
    sprite_bipedal_mutant_metasprite_7,
    sprite_bipedal_mutant_metasprite_8,
    sprite_bipedal_mutant_metasprite_9,
    sprite_bipedal_mutant_metasprite_9,
    sprite_bipedal_mutant_metasprite_9,
    sprite_bipedal_mutant_metasprite_10,
    sprite_bipedal_mutant_metasprite_10,
    sprite_bipedal_mutant_metasprite_11,
    sprite_bipedal_mutant_metasprite_12,
    sprite_bipedal_mutant_metasprite_12,
    sprite_bipedal_mutant_metasprite_12,
    sprite_bipedal_mutant_metasprite_13,
    sprite_bipedal_mutant_metasprite_13,
    sprite_bipedal_mutant_metasprite_14,
    sprite_bipedal_mutant_metasprite_15,
    sprite_bipedal_mutant_metasprite_15,
    sprite_bipedal_mutant_metasprite_15,
    sprite_bipedal_mutant_metasprite_16,
    sprite_bipedal_mutant_metasprite_16,
    sprite_bipedal_mutant_metasprite_17,
    sprite_bipedal_mutant_metasprite_18,
    sprite_bipedal_mutant_metasprite_18,
    sprite_bipedal_mutant_metasprite_18,
    sprite_bipedal_mutant_metasprite_19,
    sprite_bipedal_mutant_metasprite_19,
    sprite_bipedal_mutant_metasprite_20,
    sprite_bipedal_mutant_metasprite_21,
    sprite_bipedal_mutant_metasprite_21,
    sprite_bipedal_mutant_metasprite_21,
    sprite_bipedal_mutant_metasprite_22,
    sprite_bipedal_mutant_metasprite_22,
    sprite_bipedal_mutant_metasprite_23,
    sprite_bipedal_mutant_metasprite_24,
    sprite_bipedal_mutant_metasprite_24,
    sprite_bipedal_mutant_metasprite_25,
    sprite_bipedal_mutant_metasprite_25,
    sprite_bipedal_mutant_metasprite_26,
    sprite_bipedal_mutant_metasprite_26,
    sprite_bipedal_mutant_metasprite_27,
    sprite_bipedal_mutant_metasprite_28,
    sprite_bipedal_mutant_metasprite_29,
    sprite_bipedal_mutant_metasprite_30,
    sprite_bipedal_mutant_metasprite_30,
    sprite_bipedal_mutant_metasprite_30,
    sprite_bipedal_mutant_metasprite_31,
    sprite_bipedal_mutant_metasprite_31,
    sprite_bipedal_mutant_metasprite_32,
    sprite_bipedal_mutant_metasprite_33,
    sprite_bipedal_mutant_metasprite_33,
    sprite_bipedal_mutant_metasprite_33,
    sprite_bipedal_mutant_metasprite_34,
    sprite_bipedal_mutant_metasprite_34,
    sprite_bipedal_mutant_metasprite_35,
    sprite_bipedal_mutant_metasprite_36,
    sprite_bipedal_mutant_metasprite_36,
    sprite_bipedal_mutant_metasprite_36,
    sprite_bipedal_mutant_metasprite_37,
    sprite_bipedal_mutant_metasprite_37,
    sprite_bipedal_mutant_metasprite_38,
    sprite_bipedal_mutant_metasprite_39,
    sprite_bipedal_mutant_metasprite_39,
    sprite_bipedal_mutant_metasprite_39,
    sprite_bipedal_mutant_metasprite_40,
    sprite_bipedal_mutant_metasprite_40,
    sprite_bipedal_mutant_metasprite_41,
    sprite_bipedal_mutant_metasprite_42,
    sprite_bipedal_mutant_metasprite_42,
    sprite_bipedal_mutant_metasprite_42,
    sprite_bipedal_mutant_metasprite_43,
    sprite_bipedal_mutant_metasprite_43,
    sprite_bipedal_mutant_metasprite_44,
    sprite_bipedal_mutant_metasprite_45,
    sprite_bipedal_mutant_metasprite_45,
    sprite_bipedal_mutant_metasprite_45,
    sprite_bipedal_mutant_metasprite_24,
    sprite_bipedal_mutant_metasprite_24,
    sprite_bipedal_mutant_metasprite_46,
    sprite_bipedal_mutant_metasprite_47,
    sprite_bipedal_mutant_metasprite_47,
    sprite_bipedal_mutant_metasprite_47,
    sprite_bipedal_mutant_metasprite_48,
    sprite_bipedal_mutant_metasprite_48,
    sprite_bipedal_mutant_metasprite_49,
    sprite_bipedal_mutant_metasprite_50,
    sprite_bipedal_mutant_metasprite_50,
    sprite_bipedal_mutant_metasprite_50,
    sprite_bipedal_mutant_metasprite_51,
    sprite_bipedal_mutant_metasprite_51,
    sprite_bipedal_mutant_metasprite_52
};

const struct animation_t sprite_bipedal_mutant_animations[] = {
    {
        .start = 0,
        .end = 11
    },
    {
        .start = 0,
        .end = 11
    },
    {
        .start = 0,
        .end = 11
    },
    {
        .start = 0,
        .end = 11
    },
    {
        .start = 0,
        .end = 11
    },
    {
        .start = 0,
        .end = 11
    },
    {
        .start = 0,
        .end = 11
    },
    {
        .start = 0,
        .end = 11
    },
    {
        .start = 12,
        .end = 23
    },
    {
        .start = 12,
        .end = 23
    },
    {
        .start = 12,
        .end = 23
    },
    {
        .start = 12,
        .end = 23
    },
    {
        .start = 12,
        .end = 23
    },
    {
        .start = 12,
        .end = 23
    },
    {
        .start = 12,
        .end = 23
    },
    {
        .start = 12,
        .end = 23
    },
    {
        .start = 24,
        .end = 35
    },
    {
        .start = 24,
        .end = 35
    },
    {
        .start = 24,
        .end = 35
    },
    {
        .start = 24,
        .end = 35
    },
    {
        .start = 24,
        .end = 35
    },
    {
        .start = 24,
        .end = 35
    },
    {
        .start = 24,
        .end = 35
    },
    {
        .start = 24,
        .end = 35
    },
    {
        .start = 36,
        .end = 47
    },
    {
        .start = 36,
        .end = 47
    },
    {
        .start = 36,
        .end = 47
    },
    {
        .start = 36,
        .end = 47
    },
    {
        .start = 36,
        .end = 47
    },
    {
        .start = 36,
        .end = 47
    },
    {
        .start = 36,
        .end = 47
    },
    {
        .start = 36,
        .end = 47
    },
    {
        .start = 48,
        .end = 56
    },
    {
        .start = 48,
        .end = 56
    },
    {
        .start = 48,
        .end = 56
    },
    {
        .start = 48,
        .end = 56
    },
    {
        .start = 48,
        .end = 56
    },
    {
        .start = 48,
        .end = 56
    },
    {
        .start = 48,
        .end = 56
    },
    {
        .start = 48,
        .end = 56
    },
    {
        .start = 57,
        .end = 68
    },
    {
        .start = 57,
        .end = 68
    },
    {
        .start = 57,
        .end = 68
    },
    {
        .start = 57,
        .end = 68
    },
    {
        .start = 57,
        .end = 68
    },
    {
        .start = 57,
        .end = 68
    },
    {
        .start = 57,
        .end = 68
    },
    {
        .start = 57,
        .end = 68
    },
    {
        .start = 69,
        .end = 80
    },
    {
        .start = 69,
        .end = 80
    },
    {
        .start = 69,
        .end = 80
    },
    {
        .start = 69,
        .end = 80
    },
    {
        .start = 69,
        .end = 80
    },
    {
        .start = 69,
        .end = 80
    },
    {
        .start = 69,
        .end = 80
    },
    {
        .start = 69,
        .end = 80
    },
    {
        .start = 81,
        .end = 92
    },
    {
        .start = 81,
        .end = 92
    },
    {
        .start = 81,
        .end = 92
    },
    {
        .start = 81,
        .end = 92
    },
    {
        .start = 81,
        .end = 92
    },
    {
        .start = 81,
        .end = 92
    },
    {
        .start = 81,
        .end = 92
    },
    {
        .start = 81,
        .end = 92
    },
    {
        .start = 93,
        .end = 104
    },
    {
        .start = 93,
        .end = 104
    },
    {
        .start = 93,
        .end = 104
    },
    {
        .start = 93,
        .end = 104
    },
    {
        .start = 93,
        .end = 104
    },
    {
        .start = 93,
        .end = 104
    },
    {
        .start = 93,
        .end = 104
    },
    {
        .start = 93,
        .end = 104
    }
};

const UWORD sprite_bipedal_mutant_animations_lookup[] = {
    SPRITE_4_STATE_DEFAULT,
    SPRITE_4_STATE_SELECT,
    SPRITE_4_STATE_LEFT_RUN_DOWN,
    SPRITE_4_STATE_RIGHT_RUN_UP,
    SPRITE_4_STATE_LEFT_RUN_UP,
    SPRITE_4_STATE_DEATH,
    SPRITE_4_STATE_RIGHT_RUN_DOWN,
    SPRITE_4_STATE_IDLE_LEFT,
    SPRITE_4_STATE_IDLE_RIGHT_UP,
    SPRITE_4_STATE_IDLE_LEFT_UP,
    SPRITE_4_STATE_HURT_DOWN_LEFT,
    SPRITE_4_STATE_HURT_UP_LEFT,
    SPRITE_4_STATE_HURT_RIGHT_DOWN,
    SPRITE_4_STATE_HURT_RIGHT_UP
};

const struct spritesheet_t sprite_bipedal_mutant = {
    .n_metasprites = 105,
    .emote_origin = {
        .x = 0,
        .y = -16
    },
    .metasprites = sprite_bipedal_mutant_metasprites,
    .animations = sprite_bipedal_mutant_animations,
    .animations_lookup = sprite_bipedal_mutant_animations_lookup,
    .bounds = {
        .left = 4,
        .bottom = 7,
        .right = 9,
        .top = -7
    },
    .tileset = TO_FAR_PTR_T(sprite_bipedal_mutant_tileset),
    .cgb_tileset = TO_FAR_PTR_T(sprite_bipedal_mutant_bank2_tileset)
};
