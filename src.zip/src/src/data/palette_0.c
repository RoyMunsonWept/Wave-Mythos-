#pragma bank 255

// Palette: 0

#include "gbs_types.h"

BANKREF(palette_0)

const struct palette_t palette_0 = {
    .mask = 0xFF,
    .palette = {
        DMG_PALETTE(DMG_WHITE, DMG_LITE_GRAY, DMG_DARK_GRAY, DMG_BLACK)
    },
    .cgb_palette = {
        CGB_PALETTE(RGB(28, 30, 16), RGB(0, 22, 8), RGB(0, 13, 11), RGB(0, 0, 1)),
        CGB_PALETTE(RGB(18, 16, 15), RGB(8, 10, 9), RGB(3, 5, 5), RGB(0, 0, 1)),
        CGB_PALETTE(RGB(22, 20, 18), RGB(9, 13, 10), RGB(5, 8, 5), RGB(0, 0, 1)),
        CGB_PALETTE(RGB(23, 26, 16), RGB(6, 5, 16), RGB(9, 0, 10), RGB(0, 0, 1)),
        CGB_PALETTE(RGB(21, 29, 29), RGB(16, 23, 23), RGB(8, 12, 14), RGB(0, 0, 1)),
        CGB_PALETTE(RGB(13, 12, 11), RGB(5, 6, 5), RGB(2, 3, 3), RGB(0, 0, 1)),
        CGB_PALETTE(RGB(24, 27, 19), RGB(8, 8, 16), RGB(9, 3, 10), RGB(0, 0, 1)),
        CGB_PALETTE(RGB(25, 28, 21), RGB(10, 10, 16), RGB(9, 4, 10), RGB(0, 0, 1))
    }
};
