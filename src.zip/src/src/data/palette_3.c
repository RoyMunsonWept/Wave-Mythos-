#pragma bank 255

// Palette: 3

#include "gbs_types.h"

BANKREF(palette_3)

const struct palette_t palette_3 = {
    .mask = 0xFF,
    .palette = {
        DMG_PALETTE(DMG_WHITE, DMG_LITE_GRAY, DMG_DARK_GRAY, DMG_BLACK)
    },
    .cgb_palette = {
        CGB_PALETTE(RGB(16, 22, 31), RGB(4, 9, 27), RGB(8, 2, 12), RGB(0, 0, 8)),
        CGB_PALETTE(RGB(20, 22, 15), RGB(9, 14, 9), RGB(4, 7, 3), RGB(0, 0, 1)),
        CGB_PALETTE(RGB(22, 25, 17), RGB(12, 18, 12), RGB(6, 11, 5), RGB(0, 0, 1)),
        CGB_PALETTE(RGB(23, 26, 16), RGB(6, 5, 16), RGB(9, 0, 10), RGB(0, 0, 1)),
        CGB_PALETTE(RGB(21, 29, 29), RGB(16, 23, 23), RGB(8, 12, 14), RGB(0, 0, 1)),
        CGB_PALETTE(RGB(14, 16, 11), RGB(7, 10, 7), RGB(3, 6, 2), RGB(0, 0, 1)),
        CGB_PALETTE(RGB(29, 31, 28), RGB(22, 30, 17), RGB(10, 19, 15), RGB(4, 5, 10)),
        CGB_PALETTE(RGB(31, 31, 23), RGB(18, 25, 25), RGB(9, 13, 15), RGB(0, 0, 1))
    }
};
