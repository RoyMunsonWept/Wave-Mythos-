#pragma bank 255
// SpriteSheet: bunker

#include "gbs_types.h"



BANKREF(sprite_bunker)

#define SPRITE_5_STATE_DEFAULT 0
#define SPRITE_5_STATE_SELECT 0
#define SPRITE_5_STATE_LEFT_RUN_DOWN 0
#define SPRITE_5_STATE_RIGHT_RUN_UP 0
#define SPRITE_5_STATE_LEFT_RUN_UP 0
#define SPRITE_5_STATE_DEATH 0
#define SPRITE_5_STATE_RIGHT_RUN_DOWN 0
#define SPRITE_5_STATE_IDLE_LEFT 0
#define SPRITE_5_STATE_IDLE_RIGHT_UP 0
#define SPRITE_5_STATE_IDLE_LEFT_UP 0
#define SPRITE_5_STATE_HURT_DOWN_LEFT 0
#define SPRITE_5_STATE_HURT_UP_LEFT 0
#define SPRITE_5_STATE_HURT_RIGHT_DOWN 0
#define SPRITE_5_STATE_HURT_RIGHT_UP 0

const metasprite_t sprite_bunker_metasprite_0[]  = {
    {metasprite_end}
};

const metasprite_t * const sprite_bunker_metasprites[] = {
    sprite_bunker_metasprite_0
};

const struct animation_t sprite_bunker_animations[] = {
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    }
};

const UWORD sprite_bunker_animations_lookup[] = {
    SPRITE_5_STATE_DEFAULT
};

const struct spritesheet_t sprite_bunker = {
    .n_metasprites = 1,
    .emote_origin = {
        .x = 0,
        .y = -16
    },
    .metasprites = sprite_bunker_metasprites,
    .animations = sprite_bunker_animations,
    .animations_lookup = sprite_bunker_animations_lookup,
    .bounds = {
        .left = 0,
        .bottom = 7,
        .right = 15,
        .top = -8
    },
    .tileset = { NULL, NULL },
    .cgb_tileset = { NULL, NULL }
};
