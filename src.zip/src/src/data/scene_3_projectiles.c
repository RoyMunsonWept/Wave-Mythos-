#pragma bank 255

// Scene: wave  1 back up
// Projectiles

#include "gbs_types.h"
#include "data/sprite_monster_bullet.h"
#include "data/sprite_blood_spatter.h"

BANKREF(scene_3_projectiles)

const struct projectile_def_t scene_3_projectiles[] = {
    {
        // Projectile 0,
        .sprite = TO_FAR_PTR_T(sprite_monster_bullet),
        .move_speed = 48,
        .life_time = 60,
        .collision_group = COLLISION_GROUP_3,
        .collision_mask = COLLISION_GROUP_1,
        .bounds = {
            .left = 4,
            .bottom = 7,
            .right = 11,
            .top = 0
        },
        .anim_tick = 15,
        .animations = {
            {
                .start = 0,
                .end = 0
            },
            {
                .start = 0,
                .end = 0
            },
            {
                .start = 0,
                .end = 0
            },
            {
                .start = 0,
                .end = 0
            }
        },
        .initial_offset = 0
    },
    {
        // Projectile 1,
        .sprite = TO_FAR_PTR_T(sprite_blood_spatter),
        .move_speed = 3,
        .life_time = 60,
        .collision_group = COLLISION_GROUP_2,
        .collision_mask = 0,
        .bounds = {
            .left = 0,
            .bottom = 7,
            .right = 15,
            .top = -8
        },
        .anim_tick = 3,
        .animations = {
            {
                .start = 0,
                .end = 12
            },
            {
                .start = 0,
                .end = 12
            },
            {
                .start = 0,
                .end = 12
            },
            {
                .start = 0,
                .end = 12
            }
        },
        .initial_offset = 0
    }
};
