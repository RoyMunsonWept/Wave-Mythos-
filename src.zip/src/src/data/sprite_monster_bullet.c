#pragma bank 255
// SpriteSheet: bullet

#include "gbs_types.h"
#include "data/sprite_monster_bullet_tileset.h"


BANKREF(sprite_monster_bullet)

#define SPRITE_0_STATE_DEFAULT 0
#define SPRITE_0_STATE_SELECT 0
#define SPRITE_0_STATE_LEFT_RUN_DOWN 0
#define SPRITE_0_STATE_RIGHT_RUN_UP 0
#define SPRITE_0_STATE_LEFT_RUN_UP 0
#define SPRITE_0_STATE_DEATH 0
#define SPRITE_0_STATE_RIGHT_RUN_DOWN 0
#define SPRITE_0_STATE_IDLE_LEFT 0
#define SPRITE_0_STATE_IDLE_RIGHT_UP 0
#define SPRITE_0_STATE_IDLE_LEFT_UP 0
#define SPRITE_0_STATE_HURT_DOWN_LEFT 0
#define SPRITE_0_STATE_HURT_UP_LEFT 0
#define SPRITE_0_STATE_HURT_RIGHT_DOWN 0
#define SPRITE_0_STATE_HURT_RIGHT_UP 0

const metasprite_t sprite_monster_bullet_metasprite_0[]  = {
    { 0, 4, 0, 0 },
    {metasprite_end}
};

const metasprite_t * const sprite_monster_bullet_metasprites[] = {
    sprite_monster_bullet_metasprite_0
};

const struct animation_t sprite_monster_bullet_animations[] = {
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    }
};

const UWORD sprite_monster_bullet_animations_lookup[] = {
    SPRITE_0_STATE_DEFAULT
};

const struct spritesheet_t sprite_monster_bullet = {
    .n_metasprites = 1,
    .emote_origin = {
        .x = 0,
        .y = -32
    },
    .metasprites = sprite_monster_bullet_metasprites,
    .animations = sprite_monster_bullet_animations,
    .animations_lookup = sprite_monster_bullet_animations_lookup,
    .bounds = {
        .left = 4,
        .bottom = 7,
        .right = 11,
        .top = 0
    },
    .tileset = TO_FAR_PTR_T(sprite_monster_bullet_tileset),
    .cgb_tileset = { NULL, NULL }
};
