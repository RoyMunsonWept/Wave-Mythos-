#pragma bank 255
// SpriteSheet: tablet of wave mythos

#include "gbs_types.h"
#include "data/sprite_tablet_of_wave_mytho_tileset.h"
#include "data/sprite_tablet_of_wave_mytho_bank2_tileset.h"

BANKREF(sprite_tablet_of_wave_mytho)

#define SPRITE_6_STATE_DEFAULT 0
#define SPRITE_6_STATE_SELECT 0
#define SPRITE_6_STATE_LEFT_RUN_DOWN 0
#define SPRITE_6_STATE_RIGHT_RUN_UP 0
#define SPRITE_6_STATE_LEFT_RUN_UP 0
#define SPRITE_6_STATE_DEATH 0
#define SPRITE_6_STATE_RIGHT_RUN_DOWN 0
#define SPRITE_6_STATE_IDLE_LEFT 0
#define SPRITE_6_STATE_IDLE_RIGHT_UP 0
#define SPRITE_6_STATE_IDLE_LEFT_UP 0
#define SPRITE_6_STATE_HURT_DOWN_LEFT 0
#define SPRITE_6_STATE_HURT_UP_LEFT 0
#define SPRITE_6_STATE_HURT_RIGHT_DOWN 0
#define SPRITE_6_STATE_HURT_RIGHT_UP 0

const metasprite_t sprite_tablet_of_wave_mytho_metasprite_0[]  = {
    { 0, 8, 0, 6 }, { 0, -8, 2, 6 },
    {metasprite_end}
};

const metasprite_t sprite_tablet_of_wave_mytho_metasprite_1[]  = {
    { 0, 8, 4, 6 }, { 0, -8, 6, 6 },
    {metasprite_end}
};

const metasprite_t sprite_tablet_of_wave_mytho_metasprite_2[]  = {
    { 0, 8, 0, 14 }, { 0, -8, 2, 14 },
    {metasprite_end}
};

const metasprite_t sprite_tablet_of_wave_mytho_metasprite_3[]  = {
    { 0, 8, 4, 8 }, { 0, -8, 6, 8 },
    {metasprite_end}
};

const metasprite_t * const sprite_tablet_of_wave_mytho_metasprites[] = {
    sprite_tablet_of_wave_mytho_metasprite_0,
    sprite_tablet_of_wave_mytho_metasprite_1,
    sprite_tablet_of_wave_mytho_metasprite_2,
    sprite_tablet_of_wave_mytho_metasprite_3
};

const struct animation_t sprite_tablet_of_wave_mytho_animations[] = {
    {
        .start = 0,
        .end = 3
    },
    {
        .start = 0,
        .end = 3
    },
    {
        .start = 0,
        .end = 3
    },
    {
        .start = 0,
        .end = 3
    },
    {
        .start = 0,
        .end = 3
    },
    {
        .start = 0,
        .end = 3
    },
    {
        .start = 0,
        .end = 3
    },
    {
        .start = 0,
        .end = 3
    }
};

const UWORD sprite_tablet_of_wave_mytho_animations_lookup[] = {
    SPRITE_6_STATE_DEFAULT
};

const struct spritesheet_t sprite_tablet_of_wave_mytho = {
    .n_metasprites = 4,
    .emote_origin = {
        .x = 0,
        .y = -16
    },
    .metasprites = sprite_tablet_of_wave_mytho_metasprites,
    .animations = sprite_tablet_of_wave_mytho_animations,
    .animations_lookup = sprite_tablet_of_wave_mytho_animations_lookup,
    .bounds = {
        .left = 0,
        .bottom = 7,
        .right = 15,
        .top = -8
    },
    .tileset = TO_FAR_PTR_T(sprite_tablet_of_wave_mytho_tileset),
    .cgb_tileset = TO_FAR_PTR_T(sprite_tablet_of_wave_mytho_bank2_tileset)
};
