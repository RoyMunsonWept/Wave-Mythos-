#pragma bank 255
// SpriteSheet: actor_animated

#include "gbs_types.h"
#include "data/sprite_actor_animated_tileset.h"
#include "data/sprite_actor_animated_bank2_tileset.h"

BANKREF(sprite_actor_animated)

#define SPRITE_2_STATE_DEFAULT 0
#define SPRITE_2_STATE_SELECT 8
#define SPRITE_2_STATE_LEFT_RUN_DOWN 0
#define SPRITE_2_STATE_RIGHT_RUN_UP 0
#define SPRITE_2_STATE_LEFT_RUN_UP 0
#define SPRITE_2_STATE_DEATH 0
#define SPRITE_2_STATE_RIGHT_RUN_DOWN 0
#define SPRITE_2_STATE_IDLE_LEFT 0
#define SPRITE_2_STATE_IDLE_RIGHT_UP 0
#define SPRITE_2_STATE_IDLE_LEFT_UP 0
#define SPRITE_2_STATE_HURT_DOWN_LEFT 0
#define SPRITE_2_STATE_HURT_UP_LEFT 0
#define SPRITE_2_STATE_HURT_RIGHT_DOWN 0
#define SPRITE_2_STATE_HURT_RIGHT_UP 0

const metasprite_t sprite_actor_animated_metasprite_0[]  = {
    { 0, 8, 0, 6 }, { 0, -8, 0, 38 },
    {metasprite_end}
};

const metasprite_t sprite_actor_animated_metasprite_1[]  = {
    { 0, 8, 0, 14 }, { 0, -8, 0, 46 },
    {metasprite_end}
};

const metasprite_t sprite_actor_animated_metasprite_2[]  = {
    { 0, 8, 2, 6 }, { 0, -8, 2, 38 },
    {metasprite_end}
};

const metasprite_t * const sprite_actor_animated_metasprites[] = {
    sprite_actor_animated_metasprite_0,
    sprite_actor_animated_metasprite_0,
    sprite_actor_animated_metasprite_1,
    sprite_actor_animated_metasprite_2,
    sprite_actor_animated_metasprite_1,
    sprite_actor_animated_metasprite_0
};

const struct animation_t sprite_actor_animated_animations[] = {
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 1,
        .end = 5
    },
    {
        .start = 1,
        .end = 5
    },
    {
        .start = 1,
        .end = 5
    },
    {
        .start = 1,
        .end = 5
    },
    {
        .start = 1,
        .end = 5
    },
    {
        .start = 1,
        .end = 5
    },
    {
        .start = 1,
        .end = 5
    },
    {
        .start = 1,
        .end = 5
    }
};

const UWORD sprite_actor_animated_animations_lookup[] = {
    SPRITE_2_STATE_DEFAULT,
    SPRITE_2_STATE_SELECT
};

const struct spritesheet_t sprite_actor_animated = {
    .n_metasprites = 6,
    .emote_origin = {
        .x = 0,
        .y = -16
    },
    .metasprites = sprite_actor_animated_metasprites,
    .animations = sprite_actor_animated_animations,
    .animations_lookup = sprite_actor_animated_animations_lookup,
    .bounds = {
        .left = 2,
        .bottom = 5,
        .right = 13,
        .top = -6
    },
    .tileset = TO_FAR_PTR_T(sprite_actor_animated_tileset),
    .cgb_tileset = TO_FAR_PTR_T(sprite_actor_animated_bank2_tileset)
};
