#pragma bank 255

// Palette: 4

#include "gbs_types.h"

BANKREF(palette_4)

const struct palette_t palette_4 = {
    .mask = 0xFF,
    .palette = {
        DMG_PALETTE(DMG_WHITE, DMG_WHITE, DMG_LITE_GRAY, DMG_BLACK),
        DMG_PALETTE(DMG_WHITE, DMG_WHITE, DMG_DARK_GRAY, DMG_BLACK)
    },
    .cgb_palette = {
        CGB_PALETTE(RGB(28, 28, 11), RGB(28, 28, 11), RGB(8, 9, 25), RGB(0, 3, 1)),
        CGB_PALETTE(RGB(29, 31, 17), RGB(29, 31, 17), RGB(11, 12, 23), RGB(0, 3, 4)),
        CGB_PALETTE(RGB(31, 30, 28), RGB(31, 30, 28), RGB(27, 16, 15), RGB(0, 0, 1)),
        CGB_PALETTE(RGB(31, 30, 28), RGB(31, 30, 28), RGB(27, 16, 15), RGB(0, 0, 1)),
        CGB_PALETTE(RGB(31, 30, 28), RGB(31, 30, 28), RGB(27, 16, 15), RGB(0, 0, 1)),
        CGB_PALETTE(RGB(31, 30, 28), RGB(31, 30, 28), RGB(27, 16, 15), RGB(0, 0, 1)),
        CGB_PALETTE(RGB(16, 22, 31), RGB(16, 22, 31), RGB(4, 9, 27), RGB(0, 0, 8)),
        CGB_PALETTE(RGB(25, 20, 19), RGB(25, 20, 19), RGB(25, 7, 8), RGB(7, 0, 1))
    }
};
