#pragma bank 255

// Scene: wave  1 back up
// Triggers

#include "gbs_types.h"
#include "data/trigger_0_interact.h"
#include "data/trigger_1_interact.h"
#include "data/trigger_2_interact.h"
#include "data/trigger_15_interact.h"
#include "data/trigger_16_interact.h"
#include "data/trigger_17_interact.h"

BANKREF(scene_3_triggers)

const struct trigger_t scene_3_triggers[] = {
    {
        // bunker 2 trigger,
        .x = 2,
        .y = 32,
        .width = 2,
        .height = 2,
        .script = TO_FAR_PTR_T(trigger_0_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // bunker 0 trigger,
        .x = 10,
        .y = 45,
        .width = 2,
        .height = 2,
        .script = TO_FAR_PTR_T(trigger_1_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // bunker 1 trigger,
        .x = 8,
        .y = 36,
        .width = 2,
        .height = 2,
        .script = TO_FAR_PTR_T(trigger_2_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // bunker 3 trigger,
        .x = 15,
        .y = 26,
        .width = 2,
        .height = 2,
        .script = TO_FAR_PTR_T(trigger_15_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // bunker 4 trigger,
        .x = 12,
        .y = 17,
        .width = 2,
        .height = 2,
        .script = TO_FAR_PTR_T(trigger_16_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // bunker 5 trigger,
        .x = 6,
        .y = 18,
        .width = 2,
        .height = 2,
        .script = TO_FAR_PTR_T(trigger_17_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    }
};
