#pragma bank 255

// Background: wave mythos

#include "gbs_types.h"
#include "data/bg_wave_mythos_tileset.h"
#include "data/bg_wave_mythos_cgb_tileset.h"
#include "data/bg_wave_mythos_tilemap.h"
#include "data/bg_wave_mythos_tilemap_attr.h"

BANKREF(bg_wave_mythos)

const struct background_t bg_wave_mythos = {
    .width = 20,
    .height = 54,
    .tileset = TO_FAR_PTR_T(bg_wave_mythos_tileset),
    .cgb_tileset = TO_FAR_PTR_T(bg_wave_mythos_cgb_tileset),
    .tilemap = TO_FAR_PTR_T(bg_wave_mythos_tilemap),
    .cgb_tilemap_attr = TO_FAR_PTR_T(bg_wave_mythos_tilemap_attr)
};
