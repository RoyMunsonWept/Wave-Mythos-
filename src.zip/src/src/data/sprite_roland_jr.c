#pragma bank 255
// SpriteSheet: roland_jr

#include "gbs_types.h"
#include "data/sprite_roland_jr_tileset.h"
#include "data/sprite_roland_jr_bank2_tileset.h"

BANKREF(sprite_roland_jr)

#define SPRITE_3_STATE_DEFAULT 0
#define SPRITE_3_STATE_SELECT 64
#define SPRITE_3_STATE_LEFT_RUN_DOWN 16
#define SPRITE_3_STATE_RIGHT_RUN_UP 32
#define SPRITE_3_STATE_LEFT_RUN_UP 40
#define SPRITE_3_STATE_DEATH 72
#define SPRITE_3_STATE_RIGHT_RUN_DOWN 8
#define SPRITE_3_STATE_IDLE_LEFT 24
#define SPRITE_3_STATE_IDLE_RIGHT_UP 48
#define SPRITE_3_STATE_IDLE_LEFT_UP 56
#define SPRITE_3_STATE_HURT_DOWN_LEFT 0
#define SPRITE_3_STATE_HURT_UP_LEFT 0
#define SPRITE_3_STATE_HURT_RIGHT_DOWN 0
#define SPRITE_3_STATE_HURT_RIGHT_UP 0

const metasprite_t sprite_roland_jr_metasprite_0[]  = {
    { 0, 8, 0, 0 }, { 0, -8, 2, 0 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_1[]  = {
    { 0, 8, 4, 0 }, { 0, -8, 6, 0 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_2[]  = {
    { 0, 8, 8, 0 }, { 0, -8, 10, 0 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_3[]  = {
    { 0, 8, 12, 0 }, { 0, -8, 14, 0 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_4[]  = {
    { 0, 8, 16, 6 }, { 0, -8, 18, 6 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_5[]  = {
    { 0, 8, 20, 6 }, { 0, -8, 22, 6 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_6[]  = {
    { 0, 8, 24, 6 }, { 0, -8, 26, 6 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_7[]  = {
    { 0, 8, 28, 6 }, { 0, -8, 30, 6 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_8[]  = {
    { 0, 8, 32, 6 }, { 0, -8, 34, 6 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_9[]  = {
    { 0, 0, 16, 38 }, { 0, 8, 18, 38 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_10[]  = {
    { 0, 0, 20, 38 }, { 0, 8, 22, 38 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_11[]  = {
    { 0, 0, 24, 38 }, { 0, 8, 26, 38 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_12[]  = {
    { 0, 0, 28, 38 }, { 0, 8, 30, 38 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_13[]  = {
    { 0, 0, 32, 38 }, { 0, 8, 34, 38 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_14[]  = {
    { 0, 0, 0, 32 }, { 0, 8, 2, 32 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_15[]  = {
    { 0, 0, 4, 32 }, { 0, 8, 6, 32 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_16[]  = {
    { 0, 0, 8, 32 }, { 0, 8, 10, 32 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_17[]  = {
    { 0, 0, 12, 32 }, { 0, 8, 14, 32 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_18[]  = {
    { 0, 8, 36, 6 }, { 0, -8, 38, 6 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_19[]  = {
    { 0, 8, 40, 6 }, { 0, -8, 42, 6 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_20[]  = {
    { 0, 8, 0, 14 }, { 0, -8, 2, 14 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_21[]  = {
    { 0, 8, 4, 14 }, { 0, -8, 6, 14 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_22[]  = {
    { 0, 8, 8, 14 }, { 0, -8, 10, 14 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_23[]  = {
    { 0, 0, 36, 38 }, { 0, 8, 38, 38 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_24[]  = {
    { 0, 0, 40, 38 }, { 0, 8, 42, 38 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_25[]  = {
    { 0, 0, 0, 46 }, { 0, 8, 2, 46 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_26[]  = {
    { 0, 0, 4, 46 }, { 0, 8, 6, 46 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_27[]  = {
    { 0, 0, 8, 46 }, { 0, 8, 10, 46 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_28[]  = {
    { 0, 8, 12, 8 }, { 0, -8, 14, 8 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_29[]  = {
    { 0, 8, 16, 8 }, { 0, -8, 18, 8 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_30[]  = {
    { 0, 8, 20, 8 }, { 0, -8, 14, 8 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_31[]  = {
    { 0, 8, 22, 8 }, { 0, -8, 24, 8 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_32[]  = {
    { 0, 0, 12, 40 }, { 0, 8, 14, 40 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_33[]  = {
    { 0, 0, 16, 40 }, { 0, 8, 18, 40 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_34[]  = {
    { 0, 0, 20, 40 }, { 0, 8, 14, 40 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_35[]  = {
    { 0, 0, 22, 40 }, { 0, 8, 24, 40 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_36[]  = {
    { -17, 8, 26, 14 }, { 0, -8, 26, 46 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_37[]  = {
    { -16, 8, 26, 14 }, { 0, -8, 26, 46 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_38[]  = {
    { 3, 8, 28, 15 }, { 0, -8, 30, 15 }, { -3, 8, 0, 6 }, { 0, -8, 2, 6 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_39[]  = {
    { 2, 8, 28, 15 }, { 0, -8, 30, 15 }, { 0, 8, 32, 15 }, { 0, -8, 34, 15 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_40[]  = {
    { 0, 8, 0, 7 }, { 0, -8, 2, 7 }, { 0, 8, 32, 15 }, { 0, -8, 34, 15 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_41[]  = {
    { 0, 8, 4, 7 }, { 0, -8, 6, 7 }, { -1, 8, 36, 15 }, { 0, -8, 38, 15 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_42[]  = {
    { 0, 8, 4, 7 }, { 0, -8, 6, 7 }, { 0, 9, 36, 15 }, { 0, -10, 38, 15 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_43[]  = {
    { 0, 8, 8, 7 }, { 0, -8, 10, 7 }, { 1, 10, 36, 15 }, { 0, -12, 38, 15 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_44[]  = {
    { 0, 8, 12, 7 }, { 0, -8, 14, 7 }, { 1, 10, 40, 15 }, { 0, -12, 42, 15 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_45[]  = {
    { 0, 8, 12, 7 }, { 0, -8, 14, 7 }, { 2, 11, 40, 15 }, { 0, -14, 42, 15 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_46[]  = {
    { 0, 8, 12, 7 }, { 0, -8, 14, 7 }, { 3, 11, 40, 15 }, { 0, -14, 42, 15 },
    {metasprite_end}
};

const metasprite_t sprite_roland_jr_metasprite_47[]  = {
    { 0, 8, 12, 7 }, { 0, -8, 14, 7 },
    {metasprite_end}
};

const metasprite_t * const sprite_roland_jr_metasprites[] = {
    sprite_roland_jr_metasprite_0,
    sprite_roland_jr_metasprite_1,
    sprite_roland_jr_metasprite_2,
    sprite_roland_jr_metasprite_3,
    sprite_roland_jr_metasprite_4,
    sprite_roland_jr_metasprite_5,
    sprite_roland_jr_metasprite_6,
    sprite_roland_jr_metasprite_7,
    sprite_roland_jr_metasprite_8,
    sprite_roland_jr_metasprite_6,
    sprite_roland_jr_metasprite_9,
    sprite_roland_jr_metasprite_10,
    sprite_roland_jr_metasprite_11,
    sprite_roland_jr_metasprite_12,
    sprite_roland_jr_metasprite_13,
    sprite_roland_jr_metasprite_11,
    sprite_roland_jr_metasprite_14,
    sprite_roland_jr_metasprite_15,
    sprite_roland_jr_metasprite_16,
    sprite_roland_jr_metasprite_17,
    sprite_roland_jr_metasprite_18,
    sprite_roland_jr_metasprite_19,
    sprite_roland_jr_metasprite_20,
    sprite_roland_jr_metasprite_21,
    sprite_roland_jr_metasprite_22,
    sprite_roland_jr_metasprite_20,
    sprite_roland_jr_metasprite_23,
    sprite_roland_jr_metasprite_24,
    sprite_roland_jr_metasprite_25,
    sprite_roland_jr_metasprite_26,
    sprite_roland_jr_metasprite_27,
    sprite_roland_jr_metasprite_25,
    sprite_roland_jr_metasprite_28,
    sprite_roland_jr_metasprite_29,
    sprite_roland_jr_metasprite_30,
    sprite_roland_jr_metasprite_31,
    sprite_roland_jr_metasprite_32,
    sprite_roland_jr_metasprite_33,
    sprite_roland_jr_metasprite_34,
    sprite_roland_jr_metasprite_35,
    sprite_roland_jr_metasprite_36,
    sprite_roland_jr_metasprite_37,
    sprite_roland_jr_metasprite_38,
    sprite_roland_jr_metasprite_39,
    sprite_roland_jr_metasprite_40,
    sprite_roland_jr_metasprite_41,
    sprite_roland_jr_metasprite_42,
    sprite_roland_jr_metasprite_43,
    sprite_roland_jr_metasprite_44,
    sprite_roland_jr_metasprite_45,
    sprite_roland_jr_metasprite_46,
    sprite_roland_jr_metasprite_47
};

const struct animation_t sprite_roland_jr_animations[] = {
    {
        .start = 0,
        .end = 3
    },
    {
        .start = 0,
        .end = 3
    },
    {
        .start = 0,
        .end = 3
    },
    {
        .start = 0,
        .end = 3
    },
    {
        .start = 0,
        .end = 3
    },
    {
        .start = 0,
        .end = 3
    },
    {
        .start = 0,
        .end = 3
    },
    {
        .start = 0,
        .end = 3
    },
    {
        .start = 4,
        .end = 9
    },
    {
        .start = 4,
        .end = 9
    },
    {
        .start = 4,
        .end = 9
    },
    {
        .start = 4,
        .end = 9
    },
    {
        .start = 4,
        .end = 9
    },
    {
        .start = 4,
        .end = 9
    },
    {
        .start = 4,
        .end = 9
    },
    {
        .start = 4,
        .end = 9
    },
    {
        .start = 10,
        .end = 15
    },
    {
        .start = 10,
        .end = 15
    },
    {
        .start = 10,
        .end = 15
    },
    {
        .start = 10,
        .end = 15
    },
    {
        .start = 10,
        .end = 15
    },
    {
        .start = 10,
        .end = 15
    },
    {
        .start = 10,
        .end = 15
    },
    {
        .start = 10,
        .end = 15
    },
    {
        .start = 16,
        .end = 19
    },
    {
        .start = 16,
        .end = 19
    },
    {
        .start = 16,
        .end = 19
    },
    {
        .start = 16,
        .end = 19
    },
    {
        .start = 16,
        .end = 19
    },
    {
        .start = 16,
        .end = 19
    },
    {
        .start = 16,
        .end = 19
    },
    {
        .start = 16,
        .end = 19
    },
    {
        .start = 20,
        .end = 25
    },
    {
        .start = 20,
        .end = 25
    },
    {
        .start = 20,
        .end = 25
    },
    {
        .start = 20,
        .end = 25
    },
    {
        .start = 20,
        .end = 25
    },
    {
        .start = 20,
        .end = 25
    },
    {
        .start = 20,
        .end = 25
    },
    {
        .start = 20,
        .end = 25
    },
    {
        .start = 26,
        .end = 31
    },
    {
        .start = 26,
        .end = 31
    },
    {
        .start = 26,
        .end = 31
    },
    {
        .start = 26,
        .end = 31
    },
    {
        .start = 26,
        .end = 31
    },
    {
        .start = 26,
        .end = 31
    },
    {
        .start = 26,
        .end = 31
    },
    {
        .start = 26,
        .end = 31
    },
    {
        .start = 32,
        .end = 35
    },
    {
        .start = 32,
        .end = 35
    },
    {
        .start = 32,
        .end = 35
    },
    {
        .start = 32,
        .end = 35
    },
    {
        .start = 32,
        .end = 35
    },
    {
        .start = 32,
        .end = 35
    },
    {
        .start = 32,
        .end = 35
    },
    {
        .start = 32,
        .end = 35
    },
    {
        .start = 36,
        .end = 39
    },
    {
        .start = 36,
        .end = 39
    },
    {
        .start = 36,
        .end = 39
    },
    {
        .start = 36,
        .end = 39
    },
    {
        .start = 36,
        .end = 39
    },
    {
        .start = 36,
        .end = 39
    },
    {
        .start = 36,
        .end = 39
    },
    {
        .start = 36,
        .end = 39
    },
    {
        .start = 40,
        .end = 41
    },
    {
        .start = 40,
        .end = 41
    },
    {
        .start = 40,
        .end = 41
    },
    {
        .start = 40,
        .end = 41
    },
    {
        .start = 40,
        .end = 41
    },
    {
        .start = 40,
        .end = 41
    },
    {
        .start = 40,
        .end = 41
    },
    {
        .start = 40,
        .end = 41
    },
    {
        .start = 42,
        .end = 51
    },
    {
        .start = 42,
        .end = 51
    },
    {
        .start = 42,
        .end = 51
    },
    {
        .start = 42,
        .end = 51
    },
    {
        .start = 42,
        .end = 51
    },
    {
        .start = 42,
        .end = 51
    },
    {
        .start = 42,
        .end = 51
    },
    {
        .start = 42,
        .end = 51
    }
};

const UWORD sprite_roland_jr_animations_lookup[] = {
    SPRITE_3_STATE_DEFAULT,
    SPRITE_3_STATE_SELECT,
    SPRITE_3_STATE_LEFT_RUN_DOWN,
    SPRITE_3_STATE_RIGHT_RUN_UP,
    SPRITE_3_STATE_LEFT_RUN_UP,
    SPRITE_3_STATE_DEATH,
    SPRITE_3_STATE_RIGHT_RUN_DOWN,
    SPRITE_3_STATE_IDLE_LEFT,
    SPRITE_3_STATE_IDLE_RIGHT_UP,
    SPRITE_3_STATE_IDLE_LEFT_UP
};

const struct spritesheet_t sprite_roland_jr = {
    .n_metasprites = 52,
    .emote_origin = {
        .x = 0,
        .y = -32
    },
    .metasprites = sprite_roland_jr_metasprites,
    .animations = sprite_roland_jr_animations,
    .animations_lookup = sprite_roland_jr_animations_lookup,
    .bounds = {
        .left = 3,
        .bottom = 7,
        .right = 12,
        .top = -6
    },
    .tileset = TO_FAR_PTR_T(sprite_roland_jr_tileset),
    .cgb_tileset = TO_FAR_PTR_T(sprite_roland_jr_bank2_tileset)
};
