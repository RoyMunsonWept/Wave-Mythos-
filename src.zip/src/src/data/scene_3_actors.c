#pragma bank 255

// Scene: wave  1 back up
// Actors

#include "gbs_types.h"
#include "data/sprite_roland_jr.h"
#include "data/actor_1_update.h"
#include "data/sprite_bipedal_mutant.h"
#include "data/actor_3_update.h"
#include "data/actor_3_interact.h"
#include "data/sprite_bunker.h"
#include "data/actor_16_update.h"
#include "data/sprite_tablet_of_wave_mytho.h"
#include "data/actor_17_update.h"
#include "data/sprite_bunker.h"
#include "data/actor_18_update.h"
#include "data/sprite_bunker.h"
#include "data/actor_19_update.h"
#include "data/sprite_bunker.h"
#include "data/actor_20_update.h"

BANKREF(scene_3_actors)

const struct actor_t scene_3_actors[] = {
    {
        // player man,
        .pos = {
            .x = 80 * 16,
            .y = 368 * 16
        },
        .bounds = {
            .left = 3,
            .bottom = 7,
            .right = 12,
            .top = -6
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(sprite_roland_jr),
        .move_speed = 7,
        .anim_tick = 3,
        .pinned = FALSE,
        .persistent = TRUE,
        .collision_group = COLLISION_GROUP_NONE,
        .collision_enabled = TRUE,
        .script_update = TO_FAR_PTR_T(actor_1_update),
        .reserve_tiles = 0
    },
    {
        // monster 1,
        .pos = {
            .x = 56 * 16,
            .y = 424 * 16
        },
        .bounds = {
            .left = 4,
            .bottom = 7,
            .right = 9,
            .top = -7
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(sprite_bipedal_mutant),
        .move_speed = 2,
        .anim_tick = 3,
        .pinned = FALSE,
        .persistent = TRUE,
        .collision_group = COLLISION_GROUP_1,
        .collision_enabled = TRUE,
        .script_update = TO_FAR_PTR_T(actor_3_update),
        .script = TO_FAR_PTR_T(actor_3_interact),
        .reserve_tiles = 0
    },
    {
        // bunker tiles,
        .pos = {
            .x = 0 * 16,
            .y = 424 * 16
        },
        .bounds = {
            .left = 0,
            .bottom = 7,
            .right = 15,
            .top = -8
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(sprite_bunker),
        .move_speed = 16,
        .anim_tick = 15,
        .pinned = FALSE,
        .persistent = TRUE,
        .collision_group = COLLISION_GROUP_NONE,
        .collision_enabled = TRUE,
        .script_update = TO_FAR_PTR_T(actor_16_update),
        .reserve_tiles = 0
    },
    {
        // tablet of mythos,
        .pos = {
            .x = 40 * 16,
            .y = 80 * 16
        },
        .bounds = {
            .left = 0,
            .bottom = 7,
            .right = 15,
            .top = -8
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(sprite_tablet_of_wave_mytho),
        .move_speed = 3,
        .anim_tick = 7,
        .pinned = FALSE,
        .persistent = TRUE,
        .collision_group = COLLISION_GROUP_NONE,
        .collision_enabled = TRUE,
        .script_update = TO_FAR_PTR_T(actor_17_update),
        .reserve_tiles = 0
    },
    {
        // light house lamp,
        .pos = {
            .x = 40 * 16,
            .y = 48 * 16
        },
        .bounds = {
            .left = 0,
            .bottom = 7,
            .right = 15,
            .top = -8
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(sprite_bunker),
        .move_speed = 16,
        .anim_tick = 15,
        .pinned = FALSE,
        .persistent = FALSE,
        .collision_group = COLLISION_GROUP_NONE,
        .collision_enabled = TRUE,
        .script_update = TO_FAR_PTR_T(actor_18_update),
        .reserve_tiles = 0
    },
    {
        // wave tiles,
        .pos = {
            .x = 16 * 16,
            .y = 424 * 16
        },
        .bounds = {
            .left = 0,
            .bottom = 7,
            .right = 15,
            .top = -8
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(sprite_bunker),
        .move_speed = 16,
        .anim_tick = 15,
        .pinned = FALSE,
        .persistent = TRUE,
        .collision_group = COLLISION_GROUP_NONE,
        .collision_enabled = TRUE,
        .script_update = TO_FAR_PTR_T(actor_19_update),
        .reserve_tiles = 0
    },
    {
        // monster damage to player/ win state,
        .pos = {
            .x = 144 * 16,
            .y = 424 * 16
        },
        .bounds = {
            .left = 0,
            .bottom = 7,
            .right = 15,
            .top = -8
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(sprite_bunker),
        .move_speed = 16,
        .anim_tick = 15,
        .pinned = FALSE,
        .persistent = TRUE,
        .collision_group = COLLISION_GROUP_NONE,
        .collision_enabled = TRUE,
        .script_update = TO_FAR_PTR_T(actor_20_update),
        .reserve_tiles = 0
    }
};
