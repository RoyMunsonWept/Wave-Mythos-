#pragma bank 255

// Scene: wave  1

#include "gbs_types.h"
#include "data/bg_wave_mythos.h"
#include "data/scene_4_collisions.h"
#include "data/palette_0.h"
#include "data/palette_4.h"
#include "data/sprite_actor_animated.h"
#include "data/scene_4_actors.h"
#include "data/scene_4_triggers.h"
#include "data/scene_4_sprites.h"
#include "data/scene_4_projectiles.h"
#include "data/scene_4_init.h"

BANKREF(scene_4)

const struct scene_t scene_4 = {
    .width = 20,
    .height = 54,
    .type = SCENE_TYPE_POINTNCLICK,
    .background = TO_FAR_PTR_T(bg_wave_mythos),
    .collisions = TO_FAR_PTR_T(scene_4_collisions),
    .parallax_rows = {
        PARALLAX_STEP(0,0,0)
    },
    .palette = TO_FAR_PTR_T(palette_0),
    .sprite_palette = TO_FAR_PTR_T(palette_4),
    .reserve_tiles = 0,
    .player_sprite = TO_FAR_PTR_T(sprite_actor_animated),
    .n_actors = 8,
    .n_triggers = 6,
    .n_sprites = 6,
    .n_projectiles = 2,
    .actors = TO_FAR_PTR_T(scene_4_actors),
    .triggers = TO_FAR_PTR_T(scene_4_triggers),
    .sprites = TO_FAR_PTR_T(scene_4_sprites),
    .projectiles = TO_FAR_PTR_T(scene_4_projectiles),
    .script_init = TO_FAR_PTR_T(scene_4_init)
};
